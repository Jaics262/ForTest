// App_Plugins/ChangeRationale/save-and-preview-with-message.action.js

import {
    UmbWorkspaceActionBase
} from '@umbraco-cms/backoffice/workspace';

import {
    UMB_MODAL_MANAGER_CONTEXT
} from '@umbraco-cms/backoffice/modal';

import {
    UMB_NOTIFICATION_CONTEXT
} from '@umbraco-cms/backoffice/notification';

import {
    UMB_DOCUMENT_WORKSPACE_CONTEXT
} from '@umbraco-cms/backoffice/document';

import {
    CHANGE_RATIONALE_MODAL
} from './change-rationale-modal.token.js';

import {
    setPendingChangeRationale
} from './change-rationale-api.js';

export class SaveAndPreviewWithMessageAction
    extends UmbWorkspaceActionBase {

    async execute() {
        const workspaceContext =
            await this.getContext(
                UMB_DOCUMENT_WORKSPACE_CONTEXT
            );

        const modalManager =
            await this.getContext(
                UMB_MODAL_MANAGER_CONTEXT
            );

        const notificationContext =
            await this.getContext(
                UMB_NOTIFICATION_CONTEXT
            );

        if (!workspaceContext || !modalManager) {
            throw new Error(
                'Document workspace context is unavailable.'
            );
        }

        const documentKey = workspaceContext.getUnique?.();

        if (!documentKey) {
            notificationContext?.peek('danger', {
                data: {
                    headline: 'Cannot save',
                    message:
                        'Save the new document once before adding an audit message.'
                }
            });

            return;
        }

        const modal = modalManager.open(
            this,
            CHANGE_RATIONALE_MODAL,
            {
                data: {
                    action: 'Save and preview'
                }
            }
        );

        let result;

        try {
            result = await modal.onSubmit();
        } catch {
            return;
        }

        if (!result?.message) {
            return;
        }

        try {
            await setPendingChangeRationale(
                documentKey,
                'SavePreview',
                result.message
            );

            const urlProviderAlias =
                this.manifest?.meta?.urlProviderAlias
                ?? 'umbDocumentUrlProvider';

            await workspaceContext.saveAndPreview(
                urlProviderAlias
            );
        } catch (error) {
            notificationContext?.peek('danger', {
                data: {
                    headline: 'Save and preview failed',
                    message:
                        error?.message ??
                        'The content could not be saved.'
                }
            });
        }
    }
}

export const api = SaveAndPreviewWithMessageAction;
