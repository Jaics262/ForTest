// App_Plugins/ChangeRationale/change-rationale.entrypoint.js

import {
    umbOpenModal
} from '@umbraco-cms/backoffice/modal';

import {
    UMB_NOTIFICATION_CONTEXT
} from '@umbraco-cms/backoffice/notification';

import {
    UMB_DOCUMENT_WORKSPACE_CONTEXT
} from '@umbraco-cms/backoffice/document';

import {
    CHANGE_RATIONALE_MODAL
} from './change-rationale-modal.token.js';

import {
    clearPendingChangeRationale,
    setPendingChangeRationale
} from './change-rationale-api.js';

const rollbackModalAlias = 'Umb.Modal.Rollback';
const wrappedModalName = 'Change rationale rollback modal';

function createRollbackModal(Base) {
    class SweRollbackRationaleModal extends Base {
        async onRollback() {
            const documentKey = this.currentDocument?.unique;

            const notificationContext = await this.getContext(
                UMB_NOTIFICATION_CONTEXT
            );

            if (!documentKey) {
                notificationContext?.peek('danger', {
                    data: {
                        headline: 'Cannot roll back',
                        message:
                            'The document to roll back could not be determined.'
                    }
                });

                return;
            }

            const rationale = await umbOpenModal(
                this,
                CHANGE_RATIONALE_MODAL,
                {
                    data: {
                        action: 'Rollback'
                    }
                }
            ).catch(() => undefined);

            if (!rationale?.message) {
                return;
            }

            const valueBefore = this.value;

            try {
                await setPendingChangeRationale(
                    documentKey,
                    'Rollback',
                    rationale.message
                );

                await super.onRollback();

                if (this.value === valueBefore) {
                    await clearPendingChangeRationale(
                        documentKey,
                        'Rollback'
                    );
                }
            } catch (error) {
                await clearPendingChangeRationale(
                    documentKey,
                    'Rollback'
                ).catch(() => undefined);

                notificationContext?.peek('danger', {
                    data: {
                        headline: 'Rollback failed',
                        message:
                            error?.message ??
                            'The content could not be rolled back.'
                    }
                });
            }
        }
    }

    if (!customElements.get('swe-rollback-rationale-modal')) {
        customElements.define(
            'swe-rollback-rationale-modal',
            SweRollbackRationaleModal
        );
    }

    return SweRollbackRationaleModal;
}

const savePreviewActionAlias =
    'UmbracoCommunityRollbackPreviewer.WorkspaceAction.SaveAndSharePreview';

function createSavePreviewAction(Base) {
    return class SweSaveAndPreviewAction extends Base {
        async execute() {
            const workspaceContext = await this.getContext(
                UMB_DOCUMENT_WORKSPACE_CONTEXT
            );

            const notificationContext = await this.getContext(
                UMB_NOTIFICATION_CONTEXT
            );

            const documentKey = workspaceContext?.getUnique?.();

            if (!documentKey) {
                notificationContext?.peek('danger', {
                    data: {
                        headline: 'Cannot save',
                        message:
                            'Save the new document once before adding an audit message.'
                    }
                });

                return;
            }

            const rationale = await umbOpenModal(
                this,
                CHANGE_RATIONALE_MODAL,
                {
                    data: {
                        action: 'Save and preview'
                    }
                }
            ).catch(() => undefined);

            if (!rationale?.message) {
                return;
            }

            try {
                await setPendingChangeRationale(
                    documentKey,
                    'SavePreview',
                    rationale.message
                );

                await super.execute();
            } catch (error) {
                await clearPendingChangeRationale(
                    documentKey,
                    'SavePreview'
                ).catch(() => undefined);

                notificationContext?.peek('danger', {
                    data: {
                        headline: 'Save and preview failed',
                        message:
                            error?.message ??
                            'The content could not be saved.'
                    }
                });
            }
        }
    };
}

export async function onInit(host, extensionRegistry) {
    let rollbackModalClass = null;
    let applying = false;
    let rerun = false;

    const ensureRollbackModal = async () => {
        if (applying) {
            rerun = true;
            return;
        }

        applying = true;

        try {
            do {
                rerun = false;

                const manifest = extensionRegistry.getByAlias(
                    rollbackModalAlias
                );

                if (!manifest || manifest.name === wrappedModalName) {
                    break;
                }

                if (!rollbackModalClass) {
                    if (typeof manifest.element !== 'function') {
                        break;
                    }

                    const loaded = await manifest.element();

                    if (rerun) {
                        continue;
                    }

                    const baseModal = loaded?.RpRollbackModalElement;

                    if (!baseModal) {
                        break;
                    }

                    rollbackModalClass = createRollbackModal(baseModal);
                }

                extensionRegistry.unregister(rollbackModalAlias);

                extensionRegistry.register({
                    type: 'modal',
                    alias: rollbackModalAlias,
                    name: wrappedModalName,
                    elementName: 'swe-rollback-rationale-modal',
                    element: () => Promise.resolve({
                        default: rollbackModalClass
                    })
                });
            } while (rerun);
        } finally {
            applying = false;
        }
    };

    extensionRegistry
        .byAlias(rollbackModalAlias)
        .subscribe(() => {
            ensureRollbackModal();
        });

    let savePreviewClass = null;
    let applyingSavePreview = false;
    let rerunSavePreview = false;

    const ensureSavePreviewAction = async () => {
        if (applyingSavePreview) {
            rerunSavePreview = true;
            return;
        }

        applyingSavePreview = true;

        try {
            do {
                rerunSavePreview = false;

                const manifest = extensionRegistry.getByAlias(
                    savePreviewActionAlias
                );

                if (!manifest || manifest.sweWrapped === true) {
                    break;
                }

                if (!savePreviewClass) {
                    if (typeof manifest.api !== 'function') {
                        break;
                    }

                    const loaded = manifest.api.prototype
                        ? { api: manifest.api }
                        : await manifest.api();

                    if (rerunSavePreview) {
                        continue;
                    }

                    const baseAction = loaded?.api
                        ?? loaded?.RpSaveAndShareActionElement
                        ?? loaded?.default;

                    if (!baseAction) {
                        break;
                    }

                    savePreviewClass = createSavePreviewAction(baseAction);
                }

                const { __isMatchedWithKind, ...original } = manifest;

                extensionRegistry.unregister(savePreviewActionAlias);

                extensionRegistry.register({
                    ...original,
                    sweWrapped: true,
                    api: () => Promise.resolve({
                        api: savePreviewClass,
                        default: savePreviewClass
                    })
                });
            } while (rerunSavePreview);
        } finally {
            applyingSavePreview = false;
        }
    };

    extensionRegistry
        .byAlias(savePreviewActionAlias)
        .subscribe(() => {
            ensureSavePreviewAction();
        });
}
