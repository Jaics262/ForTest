﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NPoco;
using swe.Umbraco.Extensions.ChangeRationale.Models;
using swe.Umbraco.Extensions.ChangeRationale.Services;
using Umbraco.Cms.Api.Management.Controllers;
using Umbraco.Cms.Api.Management.Routing;
using Umbraco.Cms.Core.Security;
using Umbraco.Cms.Core.Services;
using Umbraco.Cms.Infrastructure.Scoping;

namespace swe.Umbraco.Extensions.ChangeRationale.Controllers
{
    // ChangeRationale/ChangeRationaleController.cs

    [ApiVersion("1.0")]
    [VersionedApiBackOfficeRoute("change-rationale")]
    [ApiExplorerSettings(GroupName = "Change Rationale")]
    [Authorize(Policy = "BackOfficeAccess")]
    public sealed class ChangeRationaleController
        : ManagementApiControllerBase
    {
        private const int MaximumMessageLength = 500;

        private readonly IPendingChangeRationaleStore _store;

        private readonly IBackOfficeSecurityAccessor
            _backOfficeSecurityAccessor;

        private readonly IContentService _contentService;

        private readonly IScopeProvider _scopeProvider;


        public ChangeRationaleController(
            IPendingChangeRationaleStore store,
            IBackOfficeSecurityAccessor backOfficeSecurityAccessor,
            IContentService contentService,
            IScopeProvider scopeProvider)
        {
            _store = store;

            _backOfficeSecurityAccessor =
                backOfficeSecurityAccessor;

            _contentService =
                contentService;

            _scopeProvider =
                scopeProvider;
        }


        // -----------------------------------------------------
        // Store rationale temporarily before Save, Publish,
        // or Rollback
        // -----------------------------------------------------

        [HttpPost("pending")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public IActionResult SetPendingMessage(
            [FromBody] ChangeRationaleRequest request)
        {
            Guid? userKey =
                _backOfficeSecurityAccessor
                    .BackOfficeSecurity?
                    .CurrentUser?
                    .Key;

            if (userKey is null || userKey == Guid.Empty)
            {
                return Unauthorized();
            }

            if (request.DocumentKey == Guid.Empty)
            {
                return BadRequest(new
                {
                    error = "A document key is required."
                });
            }

            string message =
                request.Message?.Trim() ?? string.Empty;

            if (string.IsNullOrWhiteSpace(message))
            {
                return BadRequest(new
                {
                    error =
                        "A change-rationale message is required."
                });
            }

            if (message.Length > MaximumMessageLength)
            {
                return BadRequest(new
                {
                    error =
                        $"The message cannot exceed " +
                        $"{MaximumMessageLength} characters."
                });
            }

            if (!Enum.TryParse(
                    request.Action,
                    ignoreCase: true,
                    out ChangeRationaleAction action))
            {
                return BadRequest(new
                {
                    error =
                        "Action must be Save, Publish, Rollback, or SavePreview."
                });
            }

            _store.Set(
                userKey.Value,
                request.DocumentKey,
                action,
                message);

            return NoContent();
        }


        // -----------------------------------------------------
        // Drop a pending rationale when Rollback is cancelled
        // -----------------------------------------------------

        [HttpPost("pending/clear")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public IActionResult ClearPendingMessage(
            [FromBody] ChangeRationaleRequest request)
        {
            Guid? userKey =
                _backOfficeSecurityAccessor
                    .BackOfficeSecurity?
                    .CurrentUser?
                    .Key;

            if (userKey is null || userKey == Guid.Empty)
            {
                return Unauthorized();
            }

            if (request.DocumentKey == Guid.Empty)
            {
                return BadRequest(new
                {
                    error = "A document key is required."
                });
            }

            if (!Enum.TryParse(
                    request.Action,
                    ignoreCase: true,
                    out ChangeRationaleAction action))
            {
                return BadRequest(new
                {
                    error =
                        "Action must be Save, Publish, Rollback, or SavePreview."
                });
            }

            _store.Remove(
                userKey.Value,
                request.DocumentKey,
                action);

            return NoContent();
        }


        // -----------------------------------------------------
        // Normalize database action
        // -----------------------------------------------------

        private static string NormalizeAction(
            string? logHeader)
        {
            if (string.Equals(
                    logHeader,
                    "Publish",
                    StringComparison.OrdinalIgnoreCase))
            {
                return "Publish";
            }

            return "Save";
        }


        // -----------------------------------------------------
        // Remove internal prefix from displayed rationale
        //
        // Database:
        // Change rationale - Published: Now published
        //
        // UI:
        // Now published
        // -----------------------------------------------------

        private static string ExtractMessage(
            string? logComment)
        {
            if (string.IsNullOrWhiteSpace(logComment))
            {
                return string.Empty;
            }

            string message =
                logComment.Trim();


            string[] prefixes =
            {
                "Change rationale - Published:",
                "Change rationale - Publish:",
                "Change rationale - Rolled back:",
                "Change rationale - Rollback:",
                "Change rationale - Save and preview:",
                "Change rationale - Saved:",
                "Change rationale - Save:",
                "Change rationale -"
            };


            foreach (string prefix in prefixes)
            {
                if (message.StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return message[prefix.Length..]
                        .Trim();
                }
            }


            return message;
        }
    }


    // ---------------------------------------------------------
    // Internal NPoco mapping for the umbracoLog query
    // ---------------------------------------------------------

    internal sealed class ChangeRationaleLogRow
    {
        public int Id
        {
            get; set;
        }

        public int UserId
        {
            get; set;
        }

        public int NodeId
        {
            get; set;
        }

        public DateTime Datestamp
        {
            get; set;
        }

        public string LogHeader
        {
            get; set;
        }
            = string.Empty;

        public string LogComment
        {
            get; set;
        }
            = string.Empty;

        public string? EntityType
        {
            get; set;
        }

        public string? Parameters
        {
            get; set;
        }

        public string? Username
        {
            get; set;
        }
    }


    // ---------------------------------------------------------
    // Response consumed by message-history.element.js
    //
    // ASP.NET Core serializes these as:
    // timestamp, action, message and username
    // ---------------------------------------------------------

   
}