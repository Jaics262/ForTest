﻿using System.Collections.Concurrent;

namespace swe.Umbraco.Extensions.ChangeRationale.Services
{
    // ChangeRationale/PendingChangeRationaleStore.cs
    public interface IPendingChangeRationaleStore
    {
        void Set(
            Guid userKey,
            Guid documentKey,
            ChangeRationaleAction action,
            string message);

        string? Take(
            Guid userKey,
            Guid documentKey,
            ChangeRationaleAction action);

        void Remove(
            Guid userKey,
            Guid documentKey,
            ChangeRationaleAction action);

        void RemoveExpired();
    }

    public enum ChangeRationaleAction
    {
        Save,
        Publish,
        Rollback,
        SavePreview
    }

    internal sealed record PendingChangeRationale(
        string Message,
        DateTimeOffset Created);

    public sealed class PendingChangeRationaleStore :
        IPendingChangeRationaleStore
    {
        private readonly ConcurrentDictionary<string, PendingChangeRationale>
            _messages = new();

        private static string GetKey(
            Guid userKey,
            Guid documentKey,
            ChangeRationaleAction action)
        {
            return $"{userKey:N}:{documentKey:N}:{action}";
        }

        public void Set(
            Guid userKey,
            Guid documentKey,
            ChangeRationaleAction action,
            string message)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(message);

            RemoveExpired();

            string key = GetKey(userKey, documentKey, action);

            _messages[key] = new PendingChangeRationale(
                message.Trim(),
                DateTimeOffset.UtcNow);
        }

        public string? Take(
            Guid userKey,
            Guid documentKey,
            ChangeRationaleAction action)
        {
            string key = GetKey(userKey, documentKey, action);

            if (!_messages.TryRemove(key, out PendingChangeRationale? value))
            {
                return null;
            }

            if (value.Created < DateTimeOffset.UtcNow.AddMinutes(-10))
            {
                return null;
            }

            return value.Message;
        }

        public void Remove(
            Guid userKey,
            Guid documentKey,
            ChangeRationaleAction action)
        {
            _messages.TryRemove(
                GetKey(userKey, documentKey, action),
                out _);
        }

        public void RemoveExpired()
        {
            DateTimeOffset cutOff = DateTimeOffset.UtcNow.AddMinutes(-10);

            foreach (KeyValuePair<string, PendingChangeRationale> item in _messages)
            {
                if (item.Value.Created < cutOff)
                {
                    _messages.TryRemove(item.Key, out _);
                }
            }
        }
    }
}
