﻿using Microsoft.Extensions.Logging;
using Umbraco.Cms.Core;
using Umbraco.Cms.Core.Models;
using Umbraco.Cms.Core.Services;

namespace swe.Umbraco.Extensions.ChangeRationale.Services
{
    // ChangeRationale/ChangeRationaleAuditWriter.cs
    public interface IChangeRationaleAuditWriter
    {
        Task WriteAsync(
            IContent content,
            Guid userKey,
            ChangeRationaleAction action,
            string message);
    }

    public sealed class ChangeRationaleAuditWriter :
        IChangeRationaleAuditWriter
    {
        private readonly IAuditService _auditService;
        private readonly ILogger<ChangeRationaleAuditWriter> _logger;
        private const string ChangeRationaleEntityType = "ChangeRationale";
        public ChangeRationaleAuditWriter(
            IAuditService auditService,
            ILogger<ChangeRationaleAuditWriter> logger)
        {
            _auditService = auditService;
            _logger = logger;
        }

        public async Task WriteAsync(
    IContent content,
    Guid userKey,
    ChangeRationaleAction action,
    string message)
        {
            AuditType auditType = action switch
            {
                ChangeRationaleAction.Publish => AuditType.Publish,
                ChangeRationaleAction.Rollback => AuditType.RollBack,
                _ => AuditType.Save
            };

            string actionText = action switch
            {
                ChangeRationaleAction.Publish => "Published",
                ChangeRationaleAction.Rollback => "Rolled back",
                ChangeRationaleAction.SavePreview => "Save and preview",
                _ => "Saved"
            };

            string comment =
                $"Change rationale - {actionText}: {message.Trim()}";

            string parameters =
                System.Text.Json.JsonSerializer.Serialize(new
                {
                    source = "ChangeRationale",
                    action = action.ToString(),
                    contentKey = content.Key,
                    contentName = content.Name
                });

            var result = await _auditService.AddAsync(
                AuditType.Custom,
                userKey,
                content.Id,
                UmbracoObjectTypes.Document.GetName() ?? string.Empty,
                null,
                comment);

            if (!result.Success)
            {
                _logger.LogError(
                    "Could not write change rationale for content {ContentId}. " +
                    "Action: {Action}. Status: {Status}",
                    content.Id,
                    action,
                    result.Result);
            }
        }
    }
}
