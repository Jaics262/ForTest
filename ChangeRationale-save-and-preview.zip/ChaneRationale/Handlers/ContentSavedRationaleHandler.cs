﻿
using Microsoft.Extensions.Logging;
using swe.Umbraco.Extensions.ChangeRationale.Services;
using Umbraco.Cms.Core.Events;
using Umbraco.Cms.Core.Notifications;
using Umbraco.Cms.Core.Security;

namespace swe.Umbraco.Extensions.ChangeRationale.Handlers
{
    // ChangeRationale/ContentSavedRationaleHandler.

    public sealed class ContentSavedRationaleHandler :
        INotificationAsyncHandler<ContentSavedNotification>
    {
        private readonly IPendingChangeRationaleStore _store;
        private readonly IChangeRationaleAuditWriter _auditWriter;
        private readonly IBackOfficeSecurityAccessor _securityAccessor;
        private readonly ILogger<ContentSavedRationaleHandler> _logger;

        public ContentSavedRationaleHandler(
            IPendingChangeRationaleStore store,
            IChangeRationaleAuditWriter auditWriter,
            IBackOfficeSecurityAccessor securityAccessor,
            ILogger<ContentSavedRationaleHandler> logger)
        {
            _store = store;
            _auditWriter = auditWriter;
            _securityAccessor = securityAccessor;
            _logger = logger;
        }

        public async Task HandleAsync(
            ContentSavedNotification notification,
            CancellationToken cancellationToken)
        {
            Guid? userKey =
                _securityAccessor.BackOfficeSecurity?
                    .CurrentUser?
                    .Key;

            if (userKey is null || userKey == Guid.Empty)
            {
                _logger.LogDebug(
                    "No authenticated backoffice user was available " +
                    "for the content save.");
                return;
            }

            foreach (var content in notification.SavedEntities)
            {
                ChangeRationaleAction action = ChangeRationaleAction.Save;

                string? message = _store.Take(
                    userKey.Value,
                    content.Key,
                    ChangeRationaleAction.Save);

                if (string.IsNullOrWhiteSpace(message))
                {
                    action = ChangeRationaleAction.SavePreview;

                    message = _store.Take(
                        userKey.Value,
                        content.Key,
                        ChangeRationaleAction.SavePreview);
                }

                if (string.IsNullOrWhiteSpace(message))
                {
                    continue;
                }

                await _auditWriter.WriteAsync(
                    content,
                    userKey.Value,
                    action,
                    message);
            }
        }
    }
}
