﻿// App_Plugins/ChangeRationale/save-with-message.action.js

import {
    UmbWorkspaceActionBase
} from '@umbraco-cms/backoffice/workspace';

import {
    UMB_MODAL_MANAGER_CONTEXT
} from '@umbraco-cms/backoffice/modal';

import {
    UMB_NOTIFICATION_CONTEXT
} from '@umbraco-cms/backoffice/notification';

import {
    UMB_DOCUMENT_WORKSPACE_CONTEXT
} from '@umbraco-cms/backoffice/document';

import {
    CHANGE_RATIONALE_MODAL
} from './change-rationale-modal.token.js';

import {
    setPendingChangeRationale
} from './change-rationale-api.js';

export class SaveWithMessageAction
    extends UmbWorkspaceActionBase {

    async execute() {
        const workspaceContext =
            await this.getContext(
                UMB_DOCUMENT_WORKSPACE_CONTEXT
            );

        const modalManager =
            await this.getContext(
                UMB_MODAL_MANAGER_CONTEXT
            );

        const notificationContext =
            await this.getContext(
                UMB_NOTIFICATION_CONTEXT
            );

        if (!workspaceContext || !modalManager) {
            throw new Error(
                'Document workspace context is unavailable.'
            );
        }

        const documentKey = workspaceContext.getUnique?.();

        if (!documentKey) {
            notificationContext?.peek('danger', {
                data: {
                    headline: 'Cannot save',
                    message:
                        'Save the new document once before adding an audit message.'
                }
            });

            return;
        }

        try {
            const modal = modalManager.open(
                this,
                CHANGE_RATIONALE_MODAL,
                {
                    data: {
                        action: 'Save'
                    }
                }
            );

            const result = await modal.onSubmit();

            if (!result?.message) {
                return;
            }

            await setPendingChangeRationale(
                documentKey,
                'Save',
                result.message
            );

            await workspaceContext.requestSubmit();
        } catch (error) {
            notificationContext?.peek('danger', {
                data: {
                    headline: 'Save failed',
                    message:
                        error?.message ??
                        'The content could not be saved.'
                }
            });
        }
    }
}

export const api = SaveWithMessageAction;