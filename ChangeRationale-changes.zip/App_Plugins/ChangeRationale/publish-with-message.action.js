﻿// App_Plugins/ChangeRationale/publish-with-message.action.js

import {
    UmbWorkspaceActionBase
} from '@umbraco-cms/backoffice/workspace';

import {
    UMB_MODAL_MANAGER_CONTEXT
} from '@umbraco-cms/backoffice/modal';

import {
    UMB_NOTIFICATION_CONTEXT
} from '@umbraco-cms/backoffice/notification';

import {
    UMB_DOCUMENT_WORKSPACE_CONTEXT,
    UMB_DOCUMENT_PUBLISHING_WORKSPACE_CONTEXT
} from '@umbraco-cms/backoffice/document';

import {
    CHANGE_RATIONALE_MODAL
} from './change-rationale-modal.token.js';

import {
    setPendingChangeRationale
} from './change-rationale-api.js';


export class PublishWithMessageAction extends UmbWorkspaceActionBase {

    async execute() {

        const workspaceContext =
            await this.getContext(
                UMB_DOCUMENT_WORKSPACE_CONTEXT
            );

        const publishingContext =
            await this.getContext(
                UMB_DOCUMENT_PUBLISHING_WORKSPACE_CONTEXT
            );

        const modalManager =
            await this.getContext(
                UMB_MODAL_MANAGER_CONTEXT
            );

        const notificationContext =
            await this.getContext(
                UMB_NOTIFICATION_CONTEXT
            );

        // -----------------------------------------------------
        // Validate required contexts
        // -----------------------------------------------------

        if (!workspaceContext) {

            notificationContext?.peek('danger', {
                data: {
                    headline: 'Publish failed',
                    message:
                        'Document workspace context is unavailable.'
                }
            });

            return;
        }

        if (!publishingContext) {

            notificationContext?.peek('danger', {
                data: {
                    headline: 'Publish failed',
                    message:
                        'Document publishing workspace context is unavailable.'
                }
            });

            return;
        }

        if (!modalManager) {

            notificationContext?.peek('danger', {
                data: {
                    headline: 'Publish failed',
                    message:
                        'Modal manager context is unavailable.'
                }
            });

            return;
        }


        // -----------------------------------------------------
        // Get current document key
        // -----------------------------------------------------

        const documentKey =
            workspaceContext.getUnique?.();

        if (!documentKey) {

            notificationContext?.peek('danger', {
                data: {
                    headline: 'Cannot publish',
                    message:
                        'Save the new document once before publishing it.'
                }
            });

            return;
        }


        try {

            // -------------------------------------------------
            // 1. Open Change Rationale modal
            // -------------------------------------------------

            const modal = modalManager.open(
                this,
                CHANGE_RATIONALE_MODAL,
                {
                    data: {
                        action: 'Publish'
                    }
                }
            );


            // -------------------------------------------------
            // 2. Wait for editor to submit rationale
            // -------------------------------------------------

            const result =
                await modal.onSubmit();


            // User cancelled the modal or provided no message
            if (!result?.message) {
                return;
            }


            // -------------------------------------------------
            // 3. Store pending rationale
            //
            // This is picked up by your backend/audit logic
            // during the Publish operation.
            // -------------------------------------------------

            await setPendingChangeRationale(
                documentKey,
                'Publish',
                result.message
            );


            // -------------------------------------------------
            // 4. Save and Publish
            //
            // IMPORTANT:
            // Publishing belongs to the dedicated publishing
            // workspace context, not UMB_DOCUMENT_WORKSPACE_CONTEXT.
            // -------------------------------------------------

            await publishingContext.saveAndPublish();

        } catch (error) {

            console.error(
                'Publish with rationale failed:',
                error
            );

            // -------------------------------------------------
            // Publish/rationale failure
            // -------------------------------------------------

            notificationContext?.peek('danger', {
                data: {
                    headline: 'Publish failed',
                    message:
                        error?.message ??
                        'The content could not be published.'
                }
            });
        }
    }
}

export const api = PublishWithMessageAction;