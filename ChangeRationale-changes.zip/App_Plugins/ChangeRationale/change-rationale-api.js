﻿import { umbHttpClient } from '@umbraco-cms/backoffice/http-client';

async function postChangeRationale(url, body, fallbackMessage) {
    const result = await umbHttpClient.post({
        url,

        security: [
            {
                scheme: 'bearer',
                type: 'http'
            }
        ],

        headers: {
            'Content-Type': 'application/json'
        },

        body
    });

    if (result.error) {
        console.error('Change rationale request failed:', result.error);

        throw new Error(
            result.error?.detail ??
            result.error?.title ??
            fallbackMessage
        );
    }

    return result.data;
}

export async function setPendingChangeRationale(
    documentKey,
    action,
    message
) {
    return postChangeRationale(
        '/umbraco/management/api/v1/change-rationale/pending',
        {
            documentKey,
            action,
            message: message.trim()
        },
        'Could not store the change-rationale message.'
    );
}

export async function clearPendingChangeRationale(
    documentKey,
    action
) {
    return postChangeRationale(
        '/umbraco/management/api/v1/change-rationale/pending/clear',
        {
            documentKey,
            action
        },
        'Could not clear the change-rationale message.'
    );
}