using Microsoft.Extensions.Logging;
using swe.Umbraco.Extensions.ChangeRationale.Services;
using Umbraco.Cms.Core.Events;
using Umbraco.Cms.Core.Models;
using Umbraco.Cms.Core.Notifications;
using Umbraco.Cms.Core.Security;

namespace swe.Umbraco.Extensions.ChangeRationale.Handlers
{
    // ChangeRationale/ContentRolledBackRationaleHandler.cs

    public sealed class ContentRolledBackRationaleHandler :
        INotificationAsyncHandler<ContentRolledBackNotification>
    {
        private readonly IPendingChangeRationaleStore _store;
        private readonly IChangeRationaleAuditWriter _auditWriter;
        private readonly IBackOfficeSecurityAccessor _securityAccessor;
        private readonly ILogger<ContentRolledBackRationaleHandler> _logger;

        public ContentRolledBackRationaleHandler(
            IPendingChangeRationaleStore store,
            IChangeRationaleAuditWriter auditWriter,
            IBackOfficeSecurityAccessor securityAccessor,
            ILogger<ContentRolledBackRationaleHandler> logger)
        {
            _store = store;
            _auditWriter = auditWriter;
            _securityAccessor = securityAccessor;
            _logger = logger;
        }

        public async Task HandleAsync(
            ContentRolledBackNotification notification,
            CancellationToken cancellationToken)
        {
            Guid? userKey =
                _securityAccessor.BackOfficeSecurity?
                    .CurrentUser?
                    .Key;

            if (userKey is null || userKey == Guid.Empty)
            {
                _logger.LogDebug(
                    "No authenticated backoffice user was available " +
                    "for the content rollback.");
                return;
            }

            IContent content = notification.Entity;

            string? message = _store.Take(
                userKey.Value,
                content.Key,
                ChangeRationaleAction.Rollback);

            if (string.IsNullOrWhiteSpace(message))
            {
                return;
            }

            await _auditWriter.WriteAsync(
                content,
                userKey.Value,
                ChangeRationaleAction.Rollback,
                message);
        }
    }
}
