﻿using Microsoft.Extensions.DependencyInjection;
using swe.Umbraco.Extensions.ChangeRationale.Handlers;
using swe.Umbraco.Extensions.ChangeRationale.Services;
using Umbraco.Cms.Core.Composing;
using Umbraco.Cms.Core.Notifications;

namespace swe.Umbraco.Extensions.ChangeRationale.Composers
{
    // ChangeRationale/ChangeRationaleComposer.cs
    public sealed class ChangeRationaleComposer : IComposer
    {
        public void Compose(IUmbracoBuilder builder)
        {
            builder.Services.AddSingleton<IPendingChangeRationaleStore,
            PendingChangeRationaleStore>();

            builder.Services.AddScoped<IChangeRationaleAuditWriter,
                ChangeRationaleAuditWriter>();

            builder.AddNotificationAsyncHandler<
                ContentSavedNotification,
                ContentSavedRationaleHandler>();

            builder.AddNotificationAsyncHandler<
                ContentPublishedNotification,
                ContentPublishedRationaleHandler>();

            builder.AddNotificationAsyncHandler<
                ContentRolledBackNotification,
                ContentRolledBackRationaleHandler>();
            //builder.Services.AddHostedService<ChangeRationaleStartup>();
        }
    }
}
